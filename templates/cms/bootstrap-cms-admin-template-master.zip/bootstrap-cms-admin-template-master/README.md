# Twitter Bootstrap based CMS template from scratch.

The purpose of this project is to implement Twitter bootstrap and create a CMS Admin template from scratch.

